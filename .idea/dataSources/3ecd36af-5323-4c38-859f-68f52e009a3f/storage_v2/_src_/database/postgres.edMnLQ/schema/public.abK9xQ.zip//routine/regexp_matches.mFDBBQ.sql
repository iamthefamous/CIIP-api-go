create function regexp_matches(citext, citext) returns SETOF text[]
    immutable
    strict
    parallel safe
    rows 1
    language sql
as
$$
    SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

alter function regexp_matches(citext, citext) owner to supabase_admin;

grant execute on function regexp_matches(citext, citext) to postgres;

grant execute on function regexp_matches(citext, citext) to anon;

grant execute on function regexp_matches(citext, citext) to authenticated;

grant execute on function regexp_matches(citext, citext) to service_role;

