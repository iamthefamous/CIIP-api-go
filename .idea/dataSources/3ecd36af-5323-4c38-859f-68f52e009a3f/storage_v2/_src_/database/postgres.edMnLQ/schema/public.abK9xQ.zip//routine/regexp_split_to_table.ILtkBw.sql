create function regexp_split_to_table(citext, citext) returns SETOF text
    immutable
    strict
    parallel safe
    language sql
as
$$
    SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

alter function regexp_split_to_table(citext, citext) owner to supabase_admin;

grant execute on function regexp_split_to_table(citext, citext) to postgres;

grant execute on function regexp_split_to_table(citext, citext) to anon;

grant execute on function regexp_split_to_table(citext, citext) to authenticated;

grant execute on function regexp_split_to_table(citext, citext) to service_role;

