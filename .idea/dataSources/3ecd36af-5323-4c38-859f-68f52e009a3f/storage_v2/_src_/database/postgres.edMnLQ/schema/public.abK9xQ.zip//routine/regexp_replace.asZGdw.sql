create function regexp_replace(citext, citext, text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
    SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, $2::pg_catalog.text, $3, 'i');
$$;

alter function regexp_replace(citext, citext, text) owner to supabase_admin;

grant execute on function regexp_replace(citext, citext, text) to postgres;

grant execute on function regexp_replace(citext, citext, text) to anon;

grant execute on function regexp_replace(citext, citext, text) to authenticated;

grant execute on function regexp_replace(citext, citext, text) to service_role;

