create function strpos(citext, citext) returns integer
    immutable
    strict
    parallel safe
    language sql
as
$$
    SELECT pg_catalog.strpos( pg_catalog.lower( $1::pg_catalog.text ), pg_catalog.lower( $2::pg_catalog.text ) );
$$;

alter function strpos(citext, citext) owner to supabase_admin;

grant execute on function strpos(citext, citext) to postgres;

grant execute on function strpos(citext, citext) to anon;

grant execute on function strpos(citext, citext) to authenticated;

grant execute on function strpos(citext, citext) to service_role;

